// Sound Effects Manager - تولید أصوات بدون ملفات خارجية
class SoundManager {
  private audioContext: AudioContext | null = null;

  constructor() {
    this.initAudioContext();
  }

  private initAudioContext() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as unknown as {webkitAudioContext: typeof AudioContext}).webkitAudioContext)();
    }
  }

  resume() {
    if (this.audioContext && this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }
  }

  private playTone(frequency: number, startTime: number, duration: number, type: OscillatorType = 'sine', volume = 0.2) {
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, startTime);

    gainNode.gain.setValueAtTime(volume, startTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration);

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.start(startTime);
    oscillator.stop(startTime + duration);
  }

  playClick() {
    this.resume();
    if (!this.audioContext) return;
    this.playTone(600, this.audioContext.currentTime, 0.05, 'sine', 0.1);
  }

  playSuccess() {
    this.resume();
    if (!this.audioContext) return;
    const ctx = this.audioContext;
    this.playTone(523, ctx.currentTime, 0.1, 'sine', 0.15);
    this.playTone(659, ctx.currentTime + 0.08, 0.1, 'sine', 0.15);
    this.playTone(784, ctx.currentTime + 0.16, 0.15, 'sine', 0.15);
  }

  playLoss() {
    this.resume();
    if (!this.audioContext) return;
    const ctx = this.audioContext;
    this.playTone(392, ctx.currentTime, 0.15, 'sawtooth', 0.1);
    this.playTone(330, ctx.currentTime + 0.1, 0.15, 'sawtooth', 0.1);
    this.playTone(262, ctx.currentTime + 0.2, 0.2, 'sawtooth', 0.1);
  }

  playError() {
    this.resume();
    if (!this.audioContext) return;
    this.playTone(200, this.audioContext.currentTime, 0.2, 'square', 0.1);
  }

  playAlert() {
    this.resume();
    if (!this.audioContext) return;
    const ctx = this.audioContext;
    this.playTone(880, ctx.currentTime, 0.1, 'square', 0.1);
    this.playTone(880, ctx.currentTime + 0.15, 0.1, 'square', 0.1);
  }

  playTransition() {
    this.resume();
    if (!this.audioContext) return;
    const ctx = this.audioContext;
    this.playTone(400, ctx.currentTime, 0.05, 'sine', 0.08);
    this.playTone(600, ctx.currentTime + 0.03, 0.05, 'sine', 0.08);
  }

  playAIResponse() {
    this.resume();
    if (!this.audioContext) return;
    const ctx = this.audioContext;
    this.playTone(500, ctx.currentTime, 0.1, 'sine', 0.1);
    this.playTone(700, ctx.currentTime + 0.08, 0.1, 'sine', 0.1);
  }

  playAppOpen() {
    this.resume();
    if (!this.audioContext) return;
    const ctx = this.audioContext;
    this.playTone(300, ctx.currentTime, 0.1, 'sine', 0.15);
    this.playTone(500, ctx.currentTime + 0.05, 0.1, 'sine', 0.15);
    this.playTone(700, ctx.currentTime + 0.1, 0.15, 'sine', 0.2);
  }

  playLevelUp() {
    this.resume();
    if (!this.audioContext) return;
    const ctx = this.audioContext;
    [523, 587, 659, 698, 784, 880, 988].forEach((freq, i) => {
      this.playTone(freq, ctx.currentTime + i * 0.08, 0.15, 'sine', 0.15);
    });
  }
}

export const soundManager = new SoundManager();