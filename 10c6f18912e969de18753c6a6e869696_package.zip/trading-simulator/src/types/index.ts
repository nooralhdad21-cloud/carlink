export interface Trade {
  id: string;
  type: 'buy' | 'sell';
  symbol: string;
  price: number;
  quantity: number;
  total: number;
  timestamp: number;
  pnl?: number;
  status: 'open' | 'closed';
}

export interface Asset {
  symbol: string;
  name: string;
  nameAr: string;
  balance: number;
  avgPrice: number;
  currentPrice?: number;
  change24h?: number;
  icon: string;
}

export interface Wallet {
  usdt: number;
  assets: Asset[];
  totalValue: number;
  profitWallet: number;
  initialBalance: number;
}

export interface PriceData {
  symbol: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume: number;
  high: number;
  low: number;
}

export interface AIMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: number;
  type?: 'advice' | 'alert' | 'analysis' | 'tip' | 'welcome' | 'profit' | 'loss';
  quickReplies?: string[];
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  target: number;
  progress: number;
  reward: number;
  completed: boolean;
  claimed?: boolean;
  type: 'trades' | 'profit' | 'learning';
  xpReward: number;
}

export interface UserStats {
  level: number;
  xp: number;
  totalTrades: number;
  wins: number;
  losses: number;
  totalProfit: number;
  streak: number;
  maxStreak: number;
}

export interface LearningModule {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  content: string;
  xpReward: number;
  category: string;
}

export interface OrderBookEntry {
  price: number;
  quantity: number;
  total: number;
}

export interface ChartCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}