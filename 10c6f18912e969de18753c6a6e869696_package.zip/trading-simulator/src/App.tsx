import { useState, useEffect, useRef, useCallback } from 'react';
import { soundManager } from './utils/soundManager';
import './App.css';

// Types
interface Asset {
  symbol: string;
  name: string;
  nameAr: string;
  balance: number;
  avgPrice: number;
  currentPrice: number;
  change24h: number;
  icon: string;
}

interface Trade {
  id: string;
  type: 'buy' | 'sell';
  symbol: string;
  price: number;
  quantity: number;
  total: number;
  timestamp: number;
  pnl?: number;
  status: 'open' | 'closed';
}

interface AIMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: number;
  type?: 'advice' | 'alert' | 'analysis' | 'tip' | 'welcome';
  quickReplies?: string[];
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  target: number;
  progress: number;
  reward: number;
  completed: boolean;
  type: 'trades' | 'profit' | 'learning';
  xpReward: number;
}

// Initial crypto assets
const cryptoAssets: Asset[] = [
  { symbol: 'BTC', name: 'Bitcoin', nameAr: 'بيتكوين', balance: 0, avgPrice: 0, currentPrice: 67432.50, change24h: 2.34, icon: '₿' },
  { symbol: 'ETH', name: 'Ethereum', nameAr: 'إيثيريوم', balance: 0, avgPrice: 0, currentPrice: 3456.78, change24h: -1.23, icon: 'Ξ' },
  { symbol: 'BNB', name: 'Binance Coin', nameAr: 'بينانس', balance: 0, avgPrice: 0, currentPrice: 612.45, change24h: 0.87, icon: '◈' },
  { symbol: 'XRP', name: 'Ripple', nameAr: 'ريبل', balance: 0, avgPrice: 0, currentPrice: 0.5245, change24h: 3.45, icon: '✕' },
  { symbol: 'SOL', name: 'Solana', nameAr: 'سولانا', balance: 0, avgPrice: 0, currentPrice: 187.32, change24h: -2.11, icon: '◎' },
  { symbol: 'ADA', name: 'Cardano', nameAr: 'كاردانو', balance: 0, avgPrice: 0, currentPrice: 0.4521, change24h: 1.56, icon: '₳' },
  { symbol: 'DOGE', name: 'Dogecoin', nameAr: 'دوجكوين', balance: 0, avgPrice: 0, currentPrice: 0.1234, change24h: -0.78, icon: 'Ð' },
  { symbol: 'GOLD', name: 'Gold', nameAr: 'الذهب', balance: 0, avgPrice: 0, currentPrice: 2345.67, change24h: 0.45, icon: '🏆' },
];

// AI Advisor responses
const aiResponses = {
  welcome: [
    "أهلاً وسهلاً! أنا مساعدك الذكي في التداول 🚀",
    "مرحباً! جاهز أساعدك تربح اليوم 💰",
    "أهلاً بك! خبرتي = خبرتك في السوق 📈"
  ],
  advice: [
    "⚡ نصيحة: RSI تحت 30 يعني فرصة شراء محتملة",
    "🔔 تنبيه: BTC يقترب من مقاومة قوية - انتظر تصحيح",
    "📊 تحليل: الاتجاه الصاعد مستمر - يمكن زيادة المراكز",
    "💡 نصيحة ذهبية: لا تستثمر أكثر من 10% من رصيدك",
    "🎯 نصيحة: حط Stop Loss لحماية أرباحك"
  ],
  analysis: [
    "📈 BTC يبدو قوي - يمكن الدخول بصفقة شراء",
    "📉 ETH في منطقة تشبع بيعي - فرصة للشراء",
    "⚖️ السوق حالياً محايد - انتظر إشارة أوضح",
    "🔥 SOL يبدوا صاعد - تابعه بحذر"
  ],
  tips: [
    "💎 تذكر: التحليل الفني مهم بس مو كلشي",
    "🧠 نصيحة: لا تخلي المشاعر تأثر على قرارتك",
    "📚 تعلّم: اقرأ عن إدارة المخاطر قبل أي صفقة",
    "🎯 حكمة: المشروع الأولي ما يكسب كل يوم"
  ],
  profit: [
    "🎉 مبروك! صفقتك رابحة 💰",
    "📈 وصلت هدفك! خذ أرباحك",
    "💎 أحسنت! محفظتك تنمو"
  ],
  loss: [
    "📉 لا تزعل! كل متداول يخسر",
    "🧠 تعلّم من التجربة - التالي أحسن",
    "💪 أنت قوي! حاول مرة ثانية"
  ]
};

const aiQuickReplies = [
  "🔍 تحليل BTC الحالي",
  "💡 نصيحة للمبتدئين",
  "📊 أفضل الأصول اليوم",
  "🎯 كيف أبدأ التداول؟",
  "📈 حالة السوق؟"
];

// Challenges
const initialChallenges: Challenge[] = [
  { id: '1', title: 'أول صفقة', description: 'أنجز أول صفقة تداول', target: 1, progress: 0, reward: 50, completed: false, type: 'trades', xpReward: 25 },
  { id: '2', title: 'تاجر نشط', description: 'أنجز 5 صفقات', target: 5, progress: 0, reward: 100, completed: false, type: 'trades', xpReward: 50 },
  { id: '3', title: 'ربح 100$', description: 'احقق ربح 100 دولار', target: 100, progress: 0, reward: 200, completed: false, type: 'profit', xpReward: 100 },
  { id: '4', title: 'محترف', description: 'أنجز 10 صفقات', target: 10, progress: 0, reward: 300, completed: false, type: 'trades', xpReward: 150 },
  { id: '5', title: 'متعلم', description: 'اقرأ درس واحد', target: 1, progress: 0, reward: 30, completed: false, type: 'learning', xpReward: 15 },
];

// Login Page Component
function LoginPage({ onLogin }: { onLogin: () => void }) {
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showIntro, setShowIntro] = useState(true);

  useEffect(() => {
    soundManager.playAppOpen();
    const timer = setTimeout(() => setShowIntro(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleStart = () => {
    soundManager.playClick();
    if (name.trim()) {
      setIsLoading(true);
      soundManager.playTransition();
      setTimeout(() => {
        onLogin();
      }, 1500);
    }
  };

  if (showIntro) {
    return (
      <div className="intro-screen">
        <div className="intro-logo">
          <div className="logo-icon">
            <svg viewBox="0 0 100 100" className="logo-svg">
              <defs>
                <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00d4aa"/>
                  <stop offset="100%" stopColor="#00b894"/>
                </linearGradient>
              </defs>
              <circle cx="50" cy="50" r="45" fill="url(#logoGrad)"/>
              <path d="M30 60 L45 45 L55 55 L70 35" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="70" cy="35" r="6" fill="white"/>
            </svg>
          </div>
          <h1>TradePro</h1>
          <p>محاكي التداول الذكي</p>
        </div>
      </div>
    );
  }

  return (
    <div className="login-page">
      <div className="login-bg">
        <div className="grid-pattern"></div>
        <div className="glow-orb orb1"></div>
        <div className="glow-orb orb2"></div>
        <div className="glow-orb orb3"></div>
      </div>

      <div className="login-container">
        <div className="login-header">
          <div className="login-logo">
            <svg viewBox="0 0 100 100" className="login-logo-svg">
              <defs>
                <linearGradient id="loginGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00d4aa"/>
                  <stop offset="100%" stopColor="#00b894"/>
                </linearGradient>
              </defs>
              <circle cx="50" cy="50" r="45" fill="url(#loginGrad)"/>
              <path d="M30 60 L45 45 L55 55 L70 35" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="70" cy="35" r="6" fill="white"/>
            </svg>
          </div>
          <h1>TradePro</h1>
          <p className="login-subtitle">محاكي التداول الذكي</p>
        </div>

        <div className="login-card">
          <h2>🚀 ابدأ رحلتك الآن</h2>
          <p className="login-desc">أدخل اسمك وابدأ التداول بدون مخاطر</p>

          <div className="input-group">
            <label>👤 اسمك</label>
            <input
              type="text"
              placeholder="أدخل اسمك هنا..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleStart()}
            />
          </div>

          <button
            className={`btn-start ${!name.trim() ? 'disabled' : ''}`}
            onClick={handleStart}
            disabled={!name.trim() || isLoading}
          >
            {isLoading ? (
              <span className="loading-dots">جاري البدء<span>.</span><span>.</span><span>.</span></span>
            ) : (
              <>
                <span className="btn-icon">▶</span>
                ابدأ الآن
              </>
            )}
          </button>

          <div className="login-features">
            <div className="feature-item">
              <span className="feature-icon">💰</span>
              <span>$10,000 رصيد مجاني</span>
            </div>
            <div className="feature-item">
              <span className="feature-icon">📊</span>
              <span>بيانات Binance الحقيقية</span>
            </div>
            <div className="feature-item">
              <span className="feature-icon">🎓</span>
              <span>تعلم بدون مخاطر</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// AI Advisor Component
function AIAdvisor({
  messages,
  onSend,
  selectedCrypto,
  wallet,
  recentTrade
}: {
  messages: AIMessage[];
  onSend: (msg: string) => void;
  selectedCrypto: string;
  wallet: { usdt: number; totalValue: number };
  recentTrade: Trade | null;
}) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (recentTrade) {
      const msg: AIMessage = {
        id: Date.now().toString(),
        text: recentTrade.pnl && recentTrade.pnl > 0
          ? `🎉 مبروك! حققت ربح ${recentTrade.pnl.toFixed(2)}$ من صفقة ${recentTrade.type}`
          : `📉 صفقتك أغلقت بخسارة ${Math.abs(recentTrade.pnl || 0).toFixed(2)}$`,
        isUser: false,
        timestamp: Date.now(),
        type: recentTrade.pnl && recentTrade.pnl > 0 ? 'profit' : 'loss'
      };
      onSend(msg.text);
    }
  }, [recentTrade]);

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    soundManager.playClick();

    const userMsg: AIMessage = {
      id: Date.now().toString(),
      text,
      isUser: true,
      timestamp: Date.now()
    };

    setInput('');
    onSend(text);

    setTimeout(() => {
      soundManager.playAIResponse();
      let response: string;
      let type: AIMessage['type'] = 'advice';
      let quickReplies: string[] | undefined;

      if (text.includes('تحليل') || text.includes('BTC')) {
        response = aiResponses.analysis[Math.floor(Math.random() * aiResponses.analysis.length)];
        type = 'analysis';
      } else if (text.includes('مبتدئ') || text.includes('أبدأ')) {
        response = "💡 نصائح للمبتدئين:\n\n1️⃣ ابدأ بمبالغ صغيرة\n2️⃣ تعلم التحليل الفني\n3️⃣ لا تخاطر بأكثر من 10%\n4️⃣ استخدم Stop Loss دائماً";
        type = 'tip';
      } else if (text.includes('سوق') || text.includes('حالة')) {
        response = "📊 حالة السوق حالياً:\n\n• BTC: صاعد 📈\n• ETH: محايد ➡️\n• السوق总体: إيجابي\n\n⏰ نصيحة: انتظر تصحيح للدخول";
        type = 'analysis';
      } else {
        const responses = [...aiResponses.advice, ...aiResponses.tips, ...aiResponses.analysis];
        response = responses[Math.floor(Math.random() * responses.length)];
        quickReplies = aiQuickReplies;
      }

      const aiMsg: AIMessage = {
        id: (Date.now() + 1).toString(),
        text: response,
        isUser: false,
        timestamp: Date.now(),
        type,
        quickReplies
      };

      const event = new CustomEvent('aiMessage', { detail: aiMsg });
      window.dispatchEvent(event);
    }, 1000);
  };

  return (
    <div className="ai-advisor">
      <div className="ai-header">
        <div className="ai-avatar">
          <span>🤖</span>
        </div>
        <div className="ai-info">
          <h3>المساعد الذكي</h3>
          <span className="ai-status">متصل • ذكي</span>
        </div>
      </div>

      <div className="ai-messages">
        {messages.map((msg) => (
          <div key={msg.id} className={`ai-message ${msg.isUser ? 'user' : 'ai'} ${msg.type || ''}`}>
            {!msg.isUser && <span className="msg-avatar">🤖</span>}
            <div className="msg-content">
              <p>{msg.text}</p>
              {msg.quickReplies && !msg.isUser && (
                <div className="quick-replies">
                  {msg.quickReplies.map((reply, i) => (
                    <button key={i} onClick={() => handleSend(reply)}>
                      {reply}
                    </button>
                  ))}
                </div>
              )}
            </div>
            {msg.isUser && <span className="msg-avatar">👤</span>}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="ai-input">
        <input
          type="text"
          placeholder="اسأل المساعد الذكي..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend(input)}
        />
        <button onClick={() => handleSend(input)}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>
          </svg>
        </button>
      </div>
    </div>
  );
}

// Trading Panel Component
function TradingPanel({
  asset,
  wallet,
  onBuy,
  onSell,
  isConnected
}: {
  asset: Asset;
  wallet: { usdt: number };
  onBuy: (quantity: number) => void;
  onSell: (quantity: number) => void;
  isConnected: boolean;
}) {
  const [quantity, setQuantity] = useState('');
  const [orderType, setOrderType] = useState<'buy' | 'sell'>('buy');

  const maxBuy = wallet.usdt / asset.currentPrice;
  const maxSell = asset.balance;

  const handleQuantityChange = (val: string) => {
    setQuantity(val);
  };

  const handleBuyPercent = (percent: number) => {
    soundManager.playClick();
    const max = wallet.usdt / asset.currentPrice;
    setQuantity((max * percent / 100).toFixed(6));
  };

  const handleSellPercent = (percent: number) => {
    soundManager.playClick();
    setQuantity((asset.balance * percent / 100).toFixed(6));
  };

  const handleTrade = () => {
    const qty = parseFloat(quantity);
    if (qty > 0) {
      soundManager.playClick();
      if (orderType === 'buy') {
        onBuy(qty);
      } else {
        onSell(qty);
      }
      setQuantity('');
    }
  };

  const total = parseFloat(quantity || '0') * asset.currentPrice;
  const canTrade = orderType === 'buy'
    ? total <= wallet.usdt && parseFloat(quantity || '0') > 0
    : parseFloat(quantity || '0') <= asset.balance && parseFloat(quantity || '0') > 0;

  return (
    <div className="trading-panel">
      <div className="trading-header">
        <div className="asset-info">
          <span className="asset-icon">{asset.icon}</span>
          <div>
            <h3>{asset.symbol}/USDT</h3>
            <p>{asset.nameAr}</p>
          </div>
        </div>
        <div className="price-display">
          <span className={`price ${asset.change24h >= 0 ? 'up' : 'down'}`}>
            ${asset.currentPrice.toLocaleString()}
          </span>
          <span className={`change ${asset.change24h >= 0 ? 'up' : 'down'}`}>
            {asset.change24h >= 0 ? '▲' : '▼'} {Math.abs(asset.change24h).toFixed(2)}%
          </span>
        </div>
      </div>

      <div className="order-tabs">
        <button
          className={`order-tab ${orderType === 'buy' ? 'active buy' : ''}`}
          onClick={() => { setOrderType('buy'); soundManager.playClick(); }}
        >
          شراء
        </button>
        <button
          className={`order-tab ${orderType === 'sell' ? 'active sell' : ''}`}
          onClick={() => { setOrderType('sell'); soundManager.playClick(); }}
        >
          بيع
        </button>
      </div>

      <div className="order-form">
        <div className="input-section">
          <label>الكمية</label>
          <div className="quantity-input">
            <input
              type="number"
              placeholder="0.00"
              value={quantity}
              onChange={(e) => handleQuantityChange(e.target.value)}
            />
            <span className="unit">{asset.symbol}</span>
          </div>
        </div>

        <div className="percent-buttons">
          {[25, 50, 75, 100].map(p => (
            <button key={p} onClick={() => orderType === 'buy' ? handleBuyPercent(p) : handleSellPercent(p)}>
              {p}%
            </button>
          ))}
        </div>

        <div className="order-summary">
          <div className="summary-row">
            <span>السعر</span>
            <span>${asset.currentPrice.toLocaleString()}</span>
          </div>
          <div className="summary-row">
            <span>الإجمالي</span>
            <span className="total">${total.toLocaleString()}</span>
          </div>
          <div className="summary-row available">
            <span>متاح</span>
            <span>{orderType === 'buy' ? `$${wallet.usdt.toLocaleString()}` : `${asset.balance.toFixed(6)} ${asset.symbol}`}</span>
          </div>
        </div>

        <button
          className={`trade-btn ${orderType} ${!canTrade ? 'disabled' : ''}`}
          onClick={handleTrade}
          disabled={!canTrade}
        >
          {orderType === 'buy' ? 'شراء ' : 'بيع '}{asset.symbol}
        </button>
      </div>

      <div className="connection-status">
        <span className={`status-dot ${isConnected ? 'connected' : 'disconnected'}`}></span>
        <span>{isConnected ? 'Binance متصل' : 'غير متصل'}</span>
      </div>
    </div>
  );
}

// Wallet Component
function WalletPanel({
  wallet,
  onDeposit,
  profitWallet,
  onWithdraw
}: {
  wallet: { usdt: number; initialBalance: number };
  onDeposit: (amount: number) => void;
  profitWallet: number;
  onWithdraw: () => void;
}) {
  const [showDeposit, setShowDeposit] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (amount > 0) {
      soundManager.playSuccess();
      onDeposit(amount);
      setDepositAmount('');
      setShowDeposit(false);
    }
  };

  const totalProfit = wallet.usdt - wallet.initialBalance;
  const profitPercent = ((totalProfit / wallet.initialBalance) * 100).toFixed(2);

  return (
    <div className="wallet-panel">
      <div className="wallet-cards">
        <div className="wallet-card main">
          <div className="card-header">
            <span className="card-icon">💰</span>
            <span>المحفظة الرئيسية</span>
          </div>
          <div className="balance">${wallet.usdt.toLocaleString()}</div>
          <div className="profit-badge">
            <span className={totalProfit >= 0 ? 'up' : 'down'}>
              {totalProfit >= 0 ? '▲' : '▼'} ${Math.abs(totalProfit).toFixed(2)} ({profitPercent}%)
            </span>
          </div>
          <div className="wallet-actions">
            <button onClick={() => { setShowDeposit(true); soundManager.playClick(); }}>
              <span>+</span> إيداع
            </button>
            <button onClick={() => { onWithdraw(); soundManager.playClick(); }} className="secondary">
              <span>↗</span> سحب
            </button>
          </div>
        </div>

        <div className="wallet-card profit">
          <div className="card-header">
            <span className="card-icon">📈</span>
            <span>صافي الربح</span>
          </div>
          <div className={`balance ${profitWallet >= 0 ? 'up' : 'down'}`}>
            ${profitWallet.toLocaleString()}
          </div>
          <div className="card-hint">منtransactions المنجزة</div>
        </div>

        <div className="wallet-card history">
          <div className="card-header">
            <span className="card-icon">📊</span>
            <span>الإحصائيات</span>
          </div>
          <div className="stat-row">
            <span>الرصيد الابتدائي</span>
            <span>${wallet.initialBalance.toLocaleString()}</span>
          </div>
          <div className="stat-row">
            <span>الأرباح والخسائر</span>
            <span className={totalProfit >= 0 ? 'up' : 'down'}>
              {totalProfit >= 0 ? '+' : ''}${totalProfit.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {showDeposit && (
        <div className="deposit-modal">
          <div className="modal-content">
            <h3>💰 إيداع رصيد</h3>
            <p>أدخل المبلغ الذي تريد إضافته لمحفظة التداول</p>
            <div className="deposit-input">
              <span>$</span>
              <input
                type="number"
                placeholder="أدخل المبلغ"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                autoFocus
              />
            </div>
            <div className="quick-amounts">
              {[100, 500, 1000, 5000].map(amt => (
                <button key={amt} onClick={() => setDepositAmount(amt.toString())}>
                  ${amt}
                </button>
              ))}
            </div>
            <div className="modal-actions">
              <button className="cancel" onClick={() => setShowDeposit(false)}>إلغاء</button>
              <button className="confirm" onClick={handleDeposit}>تأكيد</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Challenge Card Component
function ChallengeCard({ challenge, onClaim }: { challenge: Challenge; onClaim: () => void }) {
  const progress = (challenge.progress / challenge.target) * 100;

  return (
    <div className={`challenge-card ${challenge.completed ? 'completed' : ''}`}>
      <div className="challenge-header">
        <h4>{challenge.title}</h4>
        <span className="reward">+${challenge.reward}</span>
      </div>
      <p className="challenge-desc">{challenge.description}</p>
      <div className="progress-bar">
        <div className="progress-fill" style={{ width: `${Math.min(progress, 100)}%` }}></div>
      </div>
      <div className="challenge-footer">
        <span>{challenge.progress}/{challenge.target}</span>
        {challenge.completed && !challenge.claimed && (
          <button onClick={onClaim} className="claim-btn">🤑 استلام</button>
        )}
        {challenge.claimed && <span className="claimed">✓ تم</span>}
      </div>
    </div>
  );
}

// Portfolio Component
function PortfolioPanel({ assets, trades }: { assets: Asset[]; trades: Trade[] }) {
  const assetsWithBalance = assets.filter(a => a.balance > 0);
  const totalValue = assetsWithBalance.reduce((sum, a) => sum + (a.balance * a.currentPrice), 0) + trades.filter(t => t.status === 'open').length * 0;

  return (
    <div className="portfolio-panel">
      <div className="portfolio-header">
        <h3>📊 محفظتي</h3>
        <span className="total-value">القيمة: ${totalValue.toLocaleString()}</span>
      </div>

      <div className="assets-list">
        {assetsWithBalance.length === 0 ? (
          <div className="empty-state">
            <span>📭</span>
            <p>لا توجد أصول حالياً</p>
            <p className="hint">ابدأ بشراء عملة!</p>
          </div>
        ) : (
          assetsWithBalance.map(asset => {
            const value = asset.balance * asset.currentPrice;
            const cost = asset.balance * asset.avgPrice;
            const pnl = value - cost;
            const pnlPercent = cost > 0 ? (pnl / cost) * 100 : 0;

            return (
              <div key={asset.symbol} className="asset-row">
                <div className="asset-main">
                  <span className="asset-icon">{asset.icon}</span>
                  <div>
                    <span className="asset-name">{asset.symbol}</span>
                    <span className="asset-qty">{asset.balance.toFixed(6)}</span>
                  </div>
                </div>
                <div className="asset-value">
                  <span className="value">${value.toFixed(2)}</span>
                  <span className={`pnl ${pnl >= 0 ? 'up' : 'down'}`}>
                    {pnl >= 0 ? '+' : ''}{pnl.toFixed(2)} ({pnlPercent.toFixed(1)}%)
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="open-trades">
        <h4>📋 الصفقات المفتوحة</h4>
        {trades.filter(t => t.status === 'open').length === 0 ? (
          <p className="no-trades">لا توجد صفقات مفتوحة</p>
        ) : (
          trades.filter(t => t.status === 'open').map(trade => (
            <div key={trade.id} className="trade-row">
              <span className={`type ${trade.type}`}>{trade.type === 'buy' ? 'شراء' : 'بيع'}</span>
              <span>{trade.symbol}</span>
              <span>{trade.quantity.toFixed(4)}</span>
              <span>${trade.price.toLocaleString()}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// Main App Component
function App() {
  // State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [activeTab, setActiveTab] = useState('trade');
  const [selectedAsset, setSelectedAsset] = useState(cryptoAssets[0]);
  const [wallet, setWallet] = useState({
    usdt: 10000,
    initialBalance: 10000
  });
  const [assets, setAssets] = useState(cryptoAssets);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [aiMessages, setAiMessages] = useState<AIMessage[]>([]);
  const [challenges, setChallenges] = useState(initialChallenges.map(c => ({ ...c, claimed: false })));
  const [level, setLevel] = useState(1);
  const [xp, setXp] = useState(0);
  const [isConnected, setIsConnected] = useState(false);
  const [recentTrade, setRecentTrade] = useState<Trade | null>(null);
  const [profitWallet, setProfitWallet] = useState(0);
  const [showTutorial, setShowTutorial] = useState(false);

  // Refs
  const wsRef = useRef<WebSocket | null>(null);

  // Initialize
  useEffect(() => {
    if (isLoggedIn) {
      const welcomeMsg: AIMessage = {
        id: '1',
        text: `أهلاً ${userName}! 👋\n\nأنا مساعدك الذكي في التداول. كيف أقدر أساعدك اليوم؟\n\n💡 يمكنك سؤالي عن:\n• تحليل العملات\n• نصائح للمبتدئين\n• حالة السوق`,
        isUser: false,
        timestamp: Date.now(),
        type: 'welcome',
        quickReplies: aiQuickReplies
      };
      setAiMessages([welcomeMsg]);
    }
  }, [isLoggedIn, userName]);

  // Binance WebSocket Connection
  useEffect(() => {
    if (isLoggedIn) {
      connectBinance();
    }
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [isLoggedIn]);

  const connectBinance = () => {
    try {
      const streams = cryptoAssets.map(a => `${a.symbol.toLowerCase()}usdt@ticker`).join('/');
      const ws = new WebSocket(`wss://stream.binance.com:9443/stream?streams=${streams}`);

      ws.onopen = () => {
        setIsConnected(true);
        console.log('Connected to Binance WebSocket');
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.data) {
            const ticker = data.data;
            const symbol = ticker.s?.replace('USDT', '') || ticker.s?.replace('USD', '');

            setAssets(prev => prev.map(asset => {
              if (asset.symbol === symbol || (symbol === 'BTC' && asset.symbol === 'BTC')) {
                return {
                  ...asset,
                  currentPrice: parseFloat(ticker.c) || asset.currentPrice,
                  change24h: parseFloat(ticker.P) || asset.change24h,
                };
              }
              return asset;
            }));
          }
        } catch (e) {
          // Ignore parsing errors
        }
      };

      ws.onerror = () => {
        setIsConnected(false);
      };

      ws.onclose = () => {
        setIsConnected(false);
        setTimeout(connectBinance, 5000);
      };

      wsRef.current = ws;
    } catch (error) {
      setIsConnected(false);
    }
  };

  // Handle buy
  const handleBuy = (quantity: number) => {
    const total = quantity * selectedAsset.currentPrice;
    if (total > wallet.usdt) {
      soundManager.playError();
      return;
    }

    const trade: Trade = {
      id: Date.now().toString(),
      type: 'buy',
      symbol: selectedAsset.symbol,
      price: selectedAsset.currentPrice,
      quantity,
      total,
      timestamp: Date.now(),
      status: 'open'
    };

    setWallet(prev => ({ ...prev, usdt: prev.usdt - total }));
    setAssets(prev => prev.map(asset => {
      if (asset.symbol === selectedAsset.symbol) {
        const newBalance = asset.balance + quantity;
        const newAvgPrice = ((asset.balance * asset.avgPrice) + (quantity * selectedAsset.currentPrice)) / newBalance;
        return { ...asset, balance: newBalance, avgPrice: newAvgPrice };
      }
      return asset;
    }));
    setTrades(prev => [...prev, trade]);
    setRecentTrade(trade);

    // Update challenge
    setChallenges(prev => prev.map(c => {
      if (c.type === 'trades') {
        return { ...c, progress: c.progress + 1, completed: c.progress + 1 >= c.target };
      }
      return c;
    }));

    soundManager.playSuccess();
  };

  // Handle sell
  const handleSell = (quantity: number) => {
    const asset = assets.find(a => a.symbol === selectedAsset.symbol);
    if (!asset || asset.balance < quantity) {
      soundManager.playError();
      return;
    }

    const total = quantity * selectedAsset.currentPrice;
    const cost = quantity * asset.avgPrice;
    const pnl = total - cost;

    const trade: Trade = {
      id: Date.now().toString(),
      type: 'sell',
      symbol: selectedAsset.symbol,
      price: selectedAsset.currentPrice,
      quantity,
      total,
      timestamp: Date.now(),
      pnl,
      status: 'closed'
    };

    setWallet(prev => ({ ...prev, usdt: prev.usdt + total }));
    setProfitWallet(prev => prev + pnl);
    setAssets(prev => prev.map(a => {
      if (a.symbol === selectedAsset.symbol) {
        return { ...a, balance: a.balance - quantity };
      }
      return a;
    }));
    setTrades(prev => [...prev, trade]);
    setRecentTrade(trade);

    // Update challenges
    setChallenges(prev => prev.map(c => {
      if (c.type === 'trades') {
        const newProgress = c.progress + 1;
        return { ...c, progress: newProgress, completed: newProgress >= c.target };
      }
      if (c.type === 'profit' && pnl > 0) {
        const newProgress = c.progress + pnl;
        return { ...c, progress: newProgress, completed: newProgress >= c.target };
      }
      return c;
    }));

    if (pnl > 0) {
      soundManager.playSuccess();
    } else {
      soundManager.playLoss();
    }
  };

  // Handle AI message
  const handleAISend = (text: string) => {
    // This is handled in AIAdvisor component
  };

  // Handle AI message from window event
  useEffect(() => {
    const handler = (e: CustomEvent<AIMessage>) => {
      setAiMessages(prev => [...prev, e.detail]);
    };
    window.addEventListener('aiMessage', handler as EventListener);
    return () => window.removeEventListener('aiMessage', handler as EventListener);
  }, []);

  // Handle deposit
  const handleDeposit = (amount: number) => {
    setWallet(prev => ({
      ...prev,
      usdt: prev.usdt + amount,
      initialBalance: prev.initialBalance + amount
    }));
  };

  // Handle claim reward
  const handleClaimReward = (challengeId: string) => {
    const challenge = challenges.find(c => c.id === challengeId);
    if (challenge && challenge.completed && !challenge.claimed) {
      setWallet(prev => ({ ...prev, usdt: prev.usdt + challenge.reward }));
      setXp(prev => prev + challenge.xpReward);
      setChallenges(prev => prev.map(c => c.id === challengeId ? { ...c, claimed: true } : c));
      soundManager.playSuccess();
    }
  };

  // Handle navigation
  const handleNavigate = (tab: string) => {
    soundManager.playTransition();
    setActiveTab(tab);
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={() => {
      setIsLoggedIn(true);
      setUserName('تاجر'); // Default name
    }} />;
  }

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-right">
          <div className="logo">
            <svg viewBox="0 0 100 100" className="logo-svg">
              <defs>
                <linearGradient id="headerLogoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00d4aa"/>
                  <stop offset="100%" stopColor="#00b894"/>
                </linearGradient>
              </defs>
              <circle cx="50" cy="50" r="45" fill="url(#headerLogoGrad)"/>
              <path d="M30 60 L45 45 L55 55 L70 35" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="70" cy="35" r="6" fill="white"/>
            </svg>
            <span>TradePro</span>
          </div>
          <div className="connection-badge">
            <span className={`status-dot ${isConnected ? 'connected' : 'disconnected'}`}></span>
            {isConnected ? 'Binance متصل' : 'غير متصل'}
          </div>
        </div>

        <nav className="header-nav">
          <button className={activeTab === 'trade' ? 'active' : ''} onClick={() => handleNavigate('trade')}>
            <span>📊</span> التداول
          </button>
          <button className={activeTab === 'portfolio' ? 'active' : ''} onClick={() => handleNavigate('portfolio')}>
            <span>💼</span> المحفظة
          </button>
          <button className={activeTab === 'challenges' ? 'active' : ''} onClick={() => handleNavigate('challenges')}>
            <span>🏆</span> التحديات
          </button>
          <button className={activeTab === 'learn' ? 'active' : ''} onClick={() => handleNavigate('learn')}>
            <span>📚</span> التعلم
          </button>
        </nav>

        <div className="header-left">
          <div className="level-badge">
            <span>⭐</span>
            <span>المستوى {level}</span>
          </div>
          <div className="user-balance">
            <span className="balance-label">الرصيد</span>
            <span className="balance-value">${wallet.usdt.toLocaleString()}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="app-main">
        {activeTab === 'trade' && (
          <div className="trade-layout">
            {/* Left Panel - Trading */}
            <div className="trade-left">
              {/* Crypto Selector */}
              <div className="crypto-selector">
                <div className="selector-header">
                  <h3>العملات</h3>
                </div>
                <div className="crypto-list">
                  {assets.map(asset => (
                    <button
                      key={asset.symbol}
                      className={`crypto-item ${selectedAsset.symbol === asset.symbol ? 'active' : ''}`}
                      onClick={() => { setSelectedAsset(asset); soundManager.playClick(); }}
                    >
                      <span className="crypto-icon">{asset.icon}</span>
                      <div className="crypto-info">
                        <span className="crypto-name">{asset.symbol}</span>
                        <span className="crypto-price">${asset.currentPrice.toLocaleString()}</span>
                      </div>
                      <span className={`crypto-change ${asset.change24h >= 0 ? 'up' : 'down'}`}>
                        {asset.change24h >= 0 ? '▲' : '▼'} {Math.abs(asset.change24h).toFixed(2)}%
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Trading Panel */}
              <TradingPanel
                asset={selectedAsset}
                wallet={wallet}
                onBuy={handleBuy}
                onSell={handleSell}
                isConnected={isConnected}
              />
            </div>

            {/* Center - Chart Area */}
            <div className="trade-center">
              <div className="chart-header">
                <div className="chart-info">
                  <span className="chart-icon">{selectedAsset.icon}</span>
                  <h2>{selectedAsset.symbol}/USDT</h2>
                  <span className={`chart-price ${selectedAsset.change24h >= 0 ? 'up' : 'down'}`}>
                    ${selectedAsset.currentPrice.toLocaleString()}
                  </span>
                  <span className={`chart-change ${selectedAsset.change24h >= 0 ? 'up' : 'down'}`}>
                    {selectedAsset.change24h >= 0 ? '▲' : '▼'} {Math.abs(selectedAsset.change24h).toFixed(2)}%
                  </span>
                </div>
                <div className="chart-timeframes">
                  {['1م', '5م', '15م', '1س', '4س', '1ي'].map(tf => (
                    <button key={tf} className={tf === '1م' ? 'active' : ''}>{tf}</button>
                  ))}
                </div>
              </div>
              <div className="chart-area">
                <div className="chart-placeholder">
                  <span className="chart-icon-large">{selectedAsset.icon}</span>
                  <p>📈 الرسم البياني الحي</p>
                  <p className="chart-desc">متصال بـ Binance</p>
                  <div className="price-display-large">
                    <span className="price">${selectedAsset.currentPrice.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Panel - AI Advisor */}
            <div className="trade-right">
              <AIAdvisor
                messages={aiMessages}
                onSend={handleAISend}
                selectedCrypto={selectedAsset.symbol}
                wallet={wallet}
                recentTrade={recentTrade}
              />
              <WalletPanel
                wallet={wallet}
                onDeposit={handleDeposit}
                profitWallet={profitWallet}
                onWithdraw={() => {}}
              />
            </div>
          </div>
        )}

        {activeTab === 'portfolio' && (
          <div className="portfolio-view">
            <PortfolioPanel assets={assets} trades={trades} />
          </div>
        )}

        {activeTab === 'challenges' && (
          <div className="challenges-view">
            <div className="challenges-header">
              <h2>🏆 التحديات والمهام</h2>
              <p>أنجز التحديات واربح مكافآت</p>
            </div>
            <div className="challenges-grid">
              {challenges.map(challenge => (
                <ChallengeCard
                  key={challenge.id}
                  challenge={challenge}
                  onClaim={() => handleClaimReward(challenge.id)}
                />
              ))}
            </div>
          </div>
        )}

        {activeTab === 'learn' && (
          <div className="learn-view">
            <div className="learn-header">
              <h2>📚 مركز التعلم</h2>
              <p>تعلم التداول من الصفر</p>
            </div>
            <div className="learn-grid">
              <div className="learn-card">
                <div className="learn-icon">📖</div>
                <h3>أساسيات التداول</h3>
                <p>تعرف على المفاهيم الأساسية</p>
                <button onClick={() => soundManager.playClick()}>ابدأ التعلم</button>
              </div>
              <div className="learn-card">
                <div className="learn-icon">📊</div>
                <h3>التحليل الفني</h3>
                <p>تعلم قراءة الرسوم البيانية</p>
                <button onClick={() => soundManager.playClick()}>ابدأ التعلم</button>
              </div>
              <div className="learn-card">
                <div className="learn-icon">⚠️</div>
                <h3>إدارة المخاطر</h3>
                <p>كيف تحمي رأس مالك</p>
                <button onClick={() => soundManager.playClick()}>ابدأ التعلم</button>
              </div>
              <div className="learn-card">
                <div className="learn-icon">🧠</div>
                <h3>سيكولوجية التداول</h3>
                <p>تحكم في مشاعرك</p>
                <button onClick={() => soundManager.playClick()}>ابدأ التعلم</button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer Ticker */}
      <div className="ticker-bar">
        <div className="ticker-track">
          {[...assets, ...assets].map((asset, i) => (
            <div key={i} className="ticker-item">
              <span className="ticker-sym">{asset.icon} {asset.symbol}</span>
              <span className="ticker-price">${asset.currentPrice.toLocaleString()}</span>
              <span className={`ticker-change ${asset.change24h >= 0 ? 'up' : 'down'}`}>
                {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;